#!/bin/bash

qemu-system-x86_64 \
	-kernel bzImage \
	-append "rdinit=/sbin/init console=ttyS0 quiet" \
	-initrd initramfs.gz \
	-m 32M \
	-nographic


